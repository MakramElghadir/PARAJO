package controller;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Model.Model;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class Interfaz extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interfaz frame = new Interfaz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interfaz() {
		setAutoRequestFocus(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("CLIQUER CLIQUER!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Model Model = new Model();
			}
		});
		btnNewButton.setBounds(121, 11, 183, 23);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(121, 71, 227, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel Pajaro = new JLabel("Pajaro");
		Pajaro.setBounds(24, 74, 46, 14);
		contentPane.add(Pajaro);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(121, 133, 227, 20);
		contentPane.add(textField_1);
		
		JLabel Alas = new JLabel("alas");
		Alas.setBounds(24, 136, 46, 14);
		contentPane.add(Alas);
	}
}
