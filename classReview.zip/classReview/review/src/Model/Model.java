package Model;

public class Model { 
	
	
	
	
	
	public void main(String field1Content, String field2Content) {
		System.out.println("Nombre del Pajaro: " + field1Content);
        System.out.println(field1Content+ " Tiene " + field2Content + " alas.");
	}
	
}
