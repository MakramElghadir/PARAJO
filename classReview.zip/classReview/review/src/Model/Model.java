package Model;

public class Model { 
	
	public void main(int hal) {
		System.out.println("TOP MODEL");
	}
	
}
