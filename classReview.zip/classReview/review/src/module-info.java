/**
 * 
 */
/**
 * 
 */
module review {
	requires java.desktop;
}